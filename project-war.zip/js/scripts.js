
$(function(){
    $('.sl').slick();
   });